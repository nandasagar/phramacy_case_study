package model;

public class Orderlist {

	private int oid,uid,itemid,quantity;
	private String requested_date,address,dispatch_status,uname;
	public Orderlist(int oid, int uid, int itemid,String requested_date, int quantity, String address,
			String dispatch_status) {
		super();
		this.oid = oid;
		this.uid = uid;
		this.itemid = itemid;
		this.quantity = quantity;
		this.requested_date = requested_date;
		this.address = address;
		this.dispatch_status = dispatch_status;

	}
	public int getOid() {
		return oid;
	}
	public void setOid(int oid) {
		this.oid = oid;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public int getItemid() {
		return itemid;
	}
	public void setItemid(int itemid) {
		this.itemid = itemid;
	}

	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getRequested_date() {
		return requested_date;
	}
	public void setRequested_date(String requested_date) {
		this.requested_date = requested_date;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Orderlist(String address) {
		super();
		this.address = address;
	}
	public String getDispatch_status() {
		return dispatch_status;
	}
	public void setDispatch_status(String dispatch_status) {
		this.dispatch_status = dispatch_status;
	}
	public Orderlist(int oid, int uid, int itemid, String requested_date,int quantity,  String address) {
		super();
		this.oid = oid;
		this.uid = uid;
		
		this.itemid = itemid;
		this.quantity = quantity;
		this.requested_date = requested_date;
		this.address = address;
	}

	public Orderlist(int quantity,int itemid) {
		super();
		this.quantity=quantity;
		this.itemid = itemid;

		
	}
	public Orderlist(int oid,String dispatch_status) {
		super();
		this.oid = oid;
		this.dispatch_status=dispatch_status;
	}
	public Orderlist(int oid) {
		super();
		this.oid = oid;
	}
	public String toString() {
		return "Order [order_id=" + oid + ", user_id=" + uid + ", item_id=" + itemid + ", request_date="
				+ requested_date + ", dispatch_status=" + dispatch_status + ", quantity=" + quantity + ", address="
				+ address + "]";
	}


}
