create database pharmacy;
#drop database pharmacy;
create database pharmacy;
use pharmacy;
create table tbl_role(rid integer primary key not null,rname varchar(20));
insert into tbl_role values(1,'customer');
insert into tbl_role values(2,'admin');
select * from tbl_role;

desc tbl_role;


create table tbl_users(rid integer ,uid integer primary key,age integer not null,phonenum varchar(12) not null,
pincode integer not null,uname varchar(20) not null,city varchar(20) not null,state varchar(20) not null,emailid varchar(30) not null,
password varchar(30) not null,FOREIGN KEY(rid) REFERENCES tbl_role(rid));
select * from tbl_users;

create table tbl_category(cid integer primary key,cname varchar(20)not null);
insert into tbl_category values(1,'personalcare');
insert into tbl_category values(2,'nutrition');
insert into tbl_category values(3,'healthcare');
select * from tbl_category;

create table tbl_product(pid integer primary key,cid integer not null,productname varchar(30) not null,
foreign key(cid) references tbl_category (cid));
insert into tbl_product values(11,1,'skincare');         #change
insert into tbl_product values(12,1,'hand and foot care');
insert into tbl_product values(13,1,'oral care');
insert into tbl_product values(14,1,'hair care');

insert into tbl_product values(15,2,'special nutrition needs');
insert into tbl_product values(16,2,'sports nutrition');
insert into tbl_product values(17,2,'vitamins and supplements');
insert into tbl_product values(18,2,'weight management');

insert into tbl_product values(19,3,'diabetes management');
insert into tbl_product values(20,3,'health accessories');
insert into tbl_product values(21,3,'hometesting kit');
select * from tbl_product;

create table tbl_item(itemid integer primary key,itemname varchar(30) not null,pid integer not null ,cid integer not null,
quantity_available integer not null,foreign key (pid) 
references tbl_product(pid),foreign key (cid) references tbl_product(cid));
insert into tbl_item values(1,'Garnier',11,1,20);
insert into tbl_item values(2,'Lakme',11,1,30);
insert into tbl_item values(3,'Himalayas',12,1,40);
insert into tbl_item values(4,'pears',12,1,50);
insert into tbl_item values(5,'loreal',13,1,60);
insert into tbl_item values(6,'face oil',13,1,70);
insert into tbl_item values(7,'moistorizer',14,1,80);
insert into tbl_item values(8,'facewash',14,1,90);
insert into tbl_item values(9,'anamix',15,2,10);
insert into tbl_item values(10,'nutrilite',15,2,20);
insert into tbl_item values(11,'herbalife',16,2,30);
insert into tbl_item values(12,'cookies',16,2,40);
insert into tbl_item values(13,'oreo',17,2,50);
insert into tbl_item values(14,'rivalus',17,2,20);
insert into tbl_item values(15,'multivitamins',18,2,60);
insert into tbl_item values(16,'muscle tech',18,2,70);
insert into tbl_item values(17,'sugarcheck',19,3,80);
insert into tbl_item values(18,'bpmachine',19,3,20);
insert into tbl_item values(19,'mi band',20,3,90);
insert into tbl_item values(20,'BP Meter',20,3,30);
insert into tbl_item values(21,'Sugar Safe',21,3,40);
insert into tbl_item values(22,'lilly',21,3,50);
select * from tbl_orderlist;
select * from tbl_users;
#removing uname  from tbl_orderlist

create table tbl_orderlist(oid integer primary key ,uid integer not null,itemid integer not null ,
requested_date date  not null,quantity integer not null,address varchar(30) not null,
dispatch_status varchar(20),
foreign key(uid) references tbl_users(uid),foreign key(itemid) references tbl_item(itemid));
desc tbl_orderlist;
#drop table tbl_orderlist;

use pharmacy;
alter table tbl_orderlist  ;
drop table tbl_orderlist;
select * from tbl_orderlist;
select * from tbl_users;

SET SQL_SAFE_UPDATES=0;
commit;