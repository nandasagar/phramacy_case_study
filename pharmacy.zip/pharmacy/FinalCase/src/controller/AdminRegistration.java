package controller;
import model.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet("/AdminRegistration")
public class AdminRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		
		
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out=response.getWriter();
		int rid=Integer.parseInt(request.getParameter("rid"));
		int uid=Integer.parseInt(request.getParameter("uid"));
		int age=Integer.parseInt(request.getParameter("age"));
		String phonenum= request.getParameter("phonenum");
		int pincode=Integer.parseInt(request.getParameter("pincode"));
		String uname= request.getParameter("uname");
		String city= request.getParameter("city");
		String state=request.getParameter("state");
		String emailid=request.getParameter("emailid");
		String password=request.getParameter("password");	
		
		Users u=new Users(rid,uid,age,phonenum,pincode,uname,city,state,emailid,password);// changed phonenum to string type
		
		int res=0;
		
		String filepath="";
	
		 try {
			try {
				res=RegistrationDAO.insertUsers1(u);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(res!=0)
		{
			filepath="CustomerChoice.jsp";
		}
		else
		{
			filepath="error.jsp";
		}
		  RequestDispatcher rd = request.getRequestDispatcher(filepath);
		   rd.forward(request, response);

	}

	
}
