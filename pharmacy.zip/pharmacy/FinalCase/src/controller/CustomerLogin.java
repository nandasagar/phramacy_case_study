package controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.*;

/**
 * Servlet implementation class CustomerLogin
 */
@WebServlet("/CustomerLogin")
public class CustomerLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out=response.getWriter();
		int uid=0;
		String password=null;
		String filepath="";
		uid=Integer.parseInt(request.getParameter("uid"));
        password=request.getParameter("password");	
        
        
    	boolean i=LoginValidate.userLoginValidate(uid);
    	
		Users u=new Users(uid,password);// changed phonenum to string type
		
		List res=null;
		
		
	
	if(i==true) {
		
	
		 try {
			res=RegistrationDAO.login(uid, password);
			if(!res.isEmpty())
			{
				filepath="CustomerChoice.jsp";
			}
			else
			{
				filepath="error.jsp";
			}
			  RequestDispatcher rd = request.getRequestDispatcher(filepath);
			   rd.forward(request, response);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	else
	{
		filepath="error.jsp";
	}

	 RequestDispatcher rd = request.getRequestDispatcher(filepath);
	   rd.forward(request, response);
		doGet(request, response);
	}

}
