package model;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



/**
 * Servlet implementation class AdminLogoutValidate
 */
@WebServlet("/AdminLogoutValidate")
public class AdminLogoutValidate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out=response.getWriter();
		String filepath="";
		try
		{
			HttpSession session=request.getSession(false);
			session.invalidate();
			 filepath="AdminLogoutSuccess.jsp";
		}
		catch(Exception e)
		{
			 filepath="error.jsp";
		}
		RequestDispatcher rd=request.getRequestDispatcher(filepath);
		rd.forward(request, response);
	}

}
