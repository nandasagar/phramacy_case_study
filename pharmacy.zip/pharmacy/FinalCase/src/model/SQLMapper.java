package model;

import java.sql.ResultSet;
import java.sql.SQLException;


import model.*;

public class SQLMapper {
	public static final String FETCHROLE="select * from tbl_role";
	public static final String FETCHRID="select rid,rname from where rid=? and rname=?";
	public static final String FETCHUSERS="select * from tbl_users";
	public static final String FETCHUSER=
			"select uid,password from tbl_users where uid=? and password=?";
	public static final String INSERTUSERS="insert into tbl_users values(?,?,?,?,?,?,?,?,?,?)";
	public static final String FETCHROLEID = 
			"Select * from tbl_users where uid = ?";
	public static final String FETCHCATEGORYID=
			"select * from tbl_category where cid=?";
	public static final String FETCHPRODUCTID=
			"select * from tbl_product where pid=?";
	public static final String FETCHITEMID=
			"select * from tbl_item  where pid=? ";
	public static final String INSERTORDER=
			"insert into tbl_orderlist(oid,uid,itemid,requested_date,quantity,address) values(?,?,?,?,?,?)";
	public static final String FETCHORDER=
			"select * from tbl_orderlist where uid=?";
	
	public static final String UPFDATEORDER=
			"update tbl_orderlist set itemid=? where uid=?" ;
	
	public static final String UPFDATEORDER3=
			"update tbl_orderlist set quantity=? where itemid=?" ;
	public static final String DELETEORDER=
			"delete from tbl_orderlist where oid=?";
	public static final String FETCHORDER1=
			"select * from tbl_orderlist";
	public static final String INSERTORDER1=
			"insert into tbl_orderlist values(?,?,?,?,?,?,?,?)";
	public static final String UPDATEORDER1=
			"update tbl_orderlist set dispatch_status=? where oid=?";
			
	
	public static final String FETCHCATEGORY="select * from tbl_category";
	public static final String FETCHPRODUCT="select * from tbl_product";
	public static final String FETCHITEM="select * from tbl_item";
	
	
	public static final ResultMapper ROLEMAPPER=
			new ResultMapper()
			{
		public Object mapRow(ResultSet rs) throws SQLException{
			int rid=rs.getInt(1);
			String rname=rs.getString(2);
			Role r=new Role(rid,rname);
			return r;
		}
			};
	
	public static final ResultMapper USERSMAPPER=
			new ResultMapper()
			{
		public Object mapRow(ResultSet rs) throws SQLException{
			int rid=rs.getInt(1);
			int uid=rs.getInt(2);
			int age=rs.getInt(3);
			String phonenum=rs.getString(4);
			int pincode=rs.getInt(5);
			String uname=rs.getString(6);
			String city=rs.getString(7);
			String state=rs.getString(8);
			String emailid=rs.getString(9);
			String password=rs.getString(10);
			Users u=new Users(rid,uid,age,phonenum,pincode,uname,city,state,emailid,password);
			return u;
		}
			};
			public static final ResultMapper USERMAPPER=
					new ResultMapper()
				{
					public Object mapRow(ResultSet rs) throws SQLException {
					int uid=rs.getInt(1);
					String password=rs.getString(2);
					Users u1 = new Users(uid,password);
						return u1;
					}//mapRow
					
				};
			public static final ResultMapper CATEGORYMAPPER=
					new ResultMapper()
					{
				public Object mapRow(ResultSet rs) throws SQLException{
					int cid=rs.getInt(1);
					String cname=rs.getString(2);
					Category c=new Category(cid,cname);
					return c;
				}
					};
					public static final ResultMapper PRODUCTMAPPER=
							new ResultMapper()
							{
						public Object mapRow(ResultSet rs) throws SQLException{
							int pid=rs.getInt(1);
							int cid=rs.getInt(2);
							String productname=rs.getString(3);
							Product p=new Product(pid,cid,productname);
							return p;
						}
							};
							public static final ResultMapper ITEMMAPPER=
									new ResultMapper()
									{
								public Object mapRow(ResultSet rs) throws SQLException{
									int itemid=rs.getInt(1);
									String itemname=rs.getString(2);
									int pid=rs.getInt(3);
									int cid=rs.getInt(4);
									int quantity_available=rs.getInt(5);
									
									Item i=new Item(itemid,pid,cid,itemname,quantity_available);
									return i;
								}
									};
									public static final ResultMapper ORDERLISTMAPPER=
											new ResultMapper()
										{
											public Object mapRow(ResultSet rs) throws SQLException {
											int oid=rs.getInt(1);
											int uid= rs.getInt(2);
										
											//String uname=rs.getString(3);
											int itemid=rs.getInt(3);
											String requested_date=rs.getString(4);
											int quantity=rs.getInt(5);
											String address=rs.getString(6);
											Orderlist o = new Orderlist(oid,uid,itemid,requested_date,quantity,address);
												return o;
											}
											
										};
										public static final ResultMapper ORDERLISTMAPPER1=
												new ResultMapper()
											{
												public Object mapRow(ResultSet rs) throws SQLException {
												int oid=rs.getInt(1);
												int uid= rs.getInt(2);
												int itemid=rs.getInt(3);
												
												String requested_date=rs.getString(4);
												int quantity=rs.getInt(5);
												String address=rs.getString(6);
												String dispatch_status=rs.getString(7);
												
												Orderlist o = new Orderlist(oid,uid,itemid,requested_date,quantity,address,dispatch_status);
													return o;
												}
												
											};
											
										
}









