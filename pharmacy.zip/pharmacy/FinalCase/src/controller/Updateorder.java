package controller;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.*;

/**
 * Servlet implementation class Updateorder
 */
@WebServlet("/Updateorder")
public class Updateorder extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out=response.getWriter();
		int oid=Integer.parseInt(request.getParameter("oid"));
		
		int itemid=Integer.parseInt(request.getParameter("itemid"));
		
		int quantity= Integer.parseInt(request.getParameter("quantity"));
		
		Orderlist o=new Orderlist(quantity,itemid);
		
		
		int res=0;
		
		String filepath="";
	
		 try {
			res=RegistrationDAO.insertOrder3(o);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(res!=0)
		{   OrderSuccess o2=new OrderSuccess(oid);
			filepath="OrderSuccess.jsp";
		}
		else
		{
			filepath="error.jsp";
		}
		  RequestDispatcher rd = request.getRequestDispatcher(filepath);
		   rd.forward(request, response);
		   doGet(request, response);
			
	}
}
