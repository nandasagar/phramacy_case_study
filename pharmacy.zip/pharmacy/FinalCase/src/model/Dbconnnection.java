package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.List;

import dcon.ConnectionHolder;

public class Dbconnnection {
	
	public static  Connection doConnection(Connection con)throws Exception
		{	
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmacy","root","Nanda$105");
			return con;
		}
	
	
}
