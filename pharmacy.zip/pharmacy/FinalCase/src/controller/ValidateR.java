package controller;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ValidateR
 */
@WebServlet("/ValidateR")
public class ValidateR extends HttpServlet {
	
    private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out=response.getWriter();
		int rid=Integer.parseInt(request.getParameter("rid"));
		int uid=Integer.parseInt(request.getParameter("uid"));
		int age=Integer.parseInt(request.getParameter("age"));
		String phonenum= request.getParameter("phonenum");
		int pincode=Integer.parseInt(request.getParameter("pincode"));
		String uname= request.getParameter("uname");
		String city= request.getParameter("city");
		String state=request.getParameter("state");
		String emailid=request.getParameter("emailid");
		String password=request.getParameter("password");	
		String address=request.getParameter("address");	
		if(rid==0 || uid==0 || age==0 || pincode==0 ||uname.isEmpty() ||phonenum.isEmpty() ||city.isEmpty() ||
				state.isEmpty() ||	password.isEmpty() || address.isEmpty() || emailid.isEmpty())
		{
			RequestDispatcher req = request.getRequestDispatcher("Register.jsp");
			req.include(request, response);
		}
		else
		{
			RequestDispatcher req = request.getRequestDispatcher("AdminRegistration");
			req.forward(request, response);
		}
	}
 
}