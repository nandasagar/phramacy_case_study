package model;

public class Item {

	

private	int itemid,pid,cid,quantity_available;
private	String itemname;
	public int getItemid() {
		return itemid;
	}
	public void setItemid(int itemid) {
		this.itemid = itemid;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public int getQuantity_available() {
		return quantity_available;
	}
	public void setQuantity_available(int quantity_available) {
		this.quantity_available = quantity_available;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	
	public Item(int itemid, int pid, int cid, String itemname, int quantity_available) {
		super();
		this.itemid = itemid;
		this.pid = pid;
		this.cid = cid;
		this.itemname = itemname;
		this.quantity_available = quantity_available;
	}
	public String toString() {
		return "Item [item_id=" + itemid + ", pid=" + pid + ", cid=" + cid + ", itemname="
				+ itemname + ", quantity_available=" + quantity_available + "]";
	}

}
