package controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.*;
/**
 * Servlet implementation class PlaceOrder
 */
@WebServlet("/PlaceOrder")
public class PlaceOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int oid=Integer.parseInt(request.getParameter("oid"));
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out=response.getWriter();
		
		/*
		 * Orderid or=new Orderid(); int oid=or.getOderId(); out.print(oid); oid=oid+1;
		 */
	//	int oid=Integer.parseInt(request.getParameter("oid"));

		int uid=Integer.parseInt(request.getParameter("uid"));
		int itemid=Integer.parseInt(request.getParameter("itemid"));
		String requested_date= request.getParameter("requested_date");
		int quantity= Integer.parseInt(request.getParameter("quantity"));
		String address= request.getParameter("address");
		
		Orderlist o=new Orderlist(oid, uid, itemid, requested_date, quantity, address);
		
		
		int res=0;
		
		String filepath="";
	
		 try {
			res=RegistrationDAO.insertOrder(o);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(res!=0)
		{   
			OrderSuccess o2=new OrderSuccess(oid);
	
			filepath="OrderSuccess.jsp";
		}
		else
		{
			filepath="error.jsp";
		}
		  RequestDispatcher rd = request.getRequestDispatcher(filepath);
		   rd.forward(request, response);
		   doGet(request, response);
			
	}


}
