package model;

public class ViewOrderAll {
	

	private int oid,uid,itemid,quantity;
	private String requested_date,address,dispatch_status,uname;
	public ViewOrderAll(int oid, int uid, int itemid, int quantity, String requested_date, String address,
			String dispatch_status, String uname) {
		super();
		this.oid = oid;
		this.uid = uid;
		this.itemid = itemid;
		this.quantity = quantity;
		this.requested_date = requested_date;
		this.address = address;
		this.dispatch_status = dispatch_status;
		this.uname = uname;
	}
	
	public ViewOrderAll(int oid, int uid, int itemid, String requested_date, int quantity, String address, String dispatch_status) {
		// TODO Auto-generated constructor stub
		super();
		this.oid = oid;
		this.uid = uid;
		this.itemid = itemid;
		this.quantity = quantity;
		this.requested_date = requested_date;
		this.address = address;
		this.dispatch_status = dispatch_status;
	
	
	}

	public void setOid(int oid) {
		this.oid = oid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public void setItemid(int itemid) {
		this.itemid = itemid;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public void setRequested_date(String requested_date) {
		this.requested_date = requested_date;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setDispatch_status(String dispatch_status) {
		this.dispatch_status = dispatch_status;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public int getOid() {
		return oid;
	}
	public int getUid() {
		return uid;
	}
	public int getItemid() {
		return itemid;
	}
	public int getQuantity() {
		return quantity;
	}
	public String getRequested_date() {
		return requested_date;
	}
	public String getAddress() {
		return address;
	}
	public String getDispatch_status() {
		return dispatch_status;
	}
	public String getUname() {
		return uname;
	}
	
	
	
	
	
	
}
