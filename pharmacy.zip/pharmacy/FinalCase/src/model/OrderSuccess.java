package model;

public class OrderSuccess {

	private static int oid;
	

	public static int getOid() {
		return oid;
	}
	public void setOid(int oid) {
		this.oid = oid;
	}
	public OrderSuccess(int oid) {
		super();
	this.oid = oid;
	}

	
}