package controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.LoginValidate;

/**
 * Servlet implementation class AdminControl
 */
@WebServlet("/AdminControl")
public class AdminControl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
	
		String name="nanda";
		String pass="123";
		String filepath="";
		
		PrintWriter out = response.getWriter();

		 
		  String userName=request.getParameter("uname");
		  String password=request.getParameter("password");
		  boolean i=LoginValidate.adminLoginValidate(userName);
		  out.println(userName);
		  if(i==true)
		  {
				  if(name.equals(userName) && pass.equals(password))
				  {
					  out.print("Welcome, "+userName); 
					  
					  HttpSession session=request.getSession();  
				      session.setAttribute("name",userName);  
				   filepath= "AdminOperation.jsp";
				  }
		  
				  else
				  {
					  filepath= "error.jsp";
				  }
				  RequestDispatcher rd = request.getRequestDispatcher(filepath);
				   rd.forward(request, response);
		  }

		  else
		  {
			  filepath= "error.jsp";
		  }
		  RequestDispatcher rd = request.getRequestDispatcher(filepath);
		   rd.forward(request, response);
	}

}
	

