package model;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

public class Orderid {
	
	 public int getOderId()
	{
int oderid=0;
		
		
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmacy","root","Nanda$105");
			PreparedStatement ps=con.prepareStatement("select oid from tbl_orderlist;");
			ResultSet rs=ps.executeQuery();         
			
			ResultSetMetaData rsmd=rs.getMetaData();


		if (rs.next()) {
		        
			oderid= rs.getInt(1);
		
			}
		}
		        catch (Exception ex) {

		            System.out.println(ex);

		        }
		return oderid;
	

	
	}
	
	

}
