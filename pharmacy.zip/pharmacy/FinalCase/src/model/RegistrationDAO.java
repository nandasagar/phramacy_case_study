package model;

import model.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

//import org.apache.log4j.Logger;


public class RegistrationDAO {
	@SuppressWarnings("unused")
	private static final ParamMapper USERSPMAPPER = null;

	// static Logger log=Logger.getLogger(RegistrationDAO.class);

	// private static int login;

	@SuppressWarnings("rawtypes")

	public static List getRegister(final int u, final int rid, final int uid, final int age, final String phonenum,
			final int pincode, final String uname, final String city, final String state, final String emailid,
			final String password) {
		Connection con = null;
		List register = null;

		try {

			con = Dbconnnection.doConnection(con);
			final ParamMapper USERSPMAPPER = new ParamMapper() {
				public void mapParam(PreparedStatement preStmt) throws SQLException {
					preStmt.setInt(1, rid);
					preStmt.setInt(2, uid);
					preStmt.setInt(3, age);
					preStmt.setString(4, phonenum);
					preStmt.setInt(5, pincode);
					preStmt.setString(6, uname);
					preStmt.setString(7, city);
					preStmt.setString(8, state);
					preStmt.setString(9, emailid);
					preStmt.setString(10, password);

				}
			};// Anonymous class

			register = DBHelper.executeSelect(con, SQLMapper.FETCHUSERS, SQLMapper.USERSMAPPER, USERSPMAPPER);
			if (con != null) {
				con.close();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return register;

	}

	public static int insertUsers1(Users u) throws DBFWException {
		ConnectionHolder ch = null;
		Connection con = null;
		int register = 0;

		try {
			con = Dbconnnection.doConnection(con);
			/*
			 * ch=ConnectionHolder.getInstance(); con=ch.getConnection();
			 */
			final ParamMapper INSERTPUSERS = new ParamMapper() {

				public void mapParam(PreparedStatement preStmt) throws SQLException {
					preStmt.setInt(1, u.getRid());
					preStmt.setInt(2, u.getUid());
					preStmt.setInt(3, u.getAge());
					preStmt.setString(4, u.getPhonenum());
					preStmt.setInt(5, u.getPincode());
					preStmt.setString(6, u.getUname());
					preStmt.setString(7, u.getCity());
					preStmt.setString(8, u.getState());
					preStmt.setString(9, u.getEmailid());
					preStmt.setString(10, u.getPassword());

				}

			};// ananymous class

			register = DBHelper.executeUpdate(con, SQLMapper.INSERTUSERS, INSERTPUSERS);
			if (con != null) {
				con.close();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return register;

	}
	// ------------------------------------------------------- 1//to login

	public static List login(final int uid, final String password) {
		ConnectionHolder ch = null;
		Connection con = null;
		List login = null;

		try {
			con = Dbconnnection.doConnection(con);
			/*
			 * ch=ConnectionHolder.getInstance(); con=ch.getConnection();
			 */
			final ParamMapper USERSPMAPPER = new ParamMapper() {

				public void mapParam(PreparedStatement preStmt) throws SQLException {
					preStmt.setInt(1, uid);
					preStmt.setString(2, password);
				}

			};// ananymous class

			login = DBHelper.executeSelect(con, SQLMapper.FETCHUSER, SQLMapper.USERMAPPER, USERSPMAPPER);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return login;

	}

	/*
	 * public static List product(final int pid, final int cid, final String
	 * productname) { ConnectionHolder ch = null; Connection con = null; List
	 * product = null;
	 * 
	 * try {
	 * 
	 * ch=ConnectionHolder.getInstance(); con=ch.getConnection(); con =
	 * Dbconnnection.doConnection(con); final ParamMapper PRODUCTPMAPPER = new
	 * ParamMapper() {
	 * 
	 * public void mapParam(PreparedStatement preStmt) throws SQLException {
	 * preStmt.setInt(1, pid); preStmt.setInt(2, cid); preStmt.setString(3,
	 * productname);
	 * 
	 * }
	 * 
	 * };// ananymous class
	 * 
	 * product = DBHelper.executeSelect(con, SQLMapper.FETCHPRODUCTID,
	 * SQLMapper.PRODUCTMAPPER, PRODUCTPMAPPER);
	 * 
	 * } catch (Exception e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); } return product;
	 * 
	 * }
	 */
	/*
	 * public static List getItem(final int itemid, final int pid, final int cid,
	 * final String itemname, final int quantity_available) {
	 * 
	 * ConnectionHolder ch=null; Connection con=null; List item=null;
	 * 
	 * try { ch=ConnectionHolder.getInstance(); con=ch.getConnection(); final
	 * ParamMapper ITEMPMAPPER=new ParamMapper() {
	 * 
	 * public void mapParam(PreparedStatement preStmt) throws SQLException {
	 * preStmt.setInt(1,itemid); preStmt.setInt(2, pid); preStmt.setInt(3, cid);
	 * preStmt.setString(4,itemname ); preStmt.setInt(5,quantity_available); }
	 * 
	 * };//ananymous class
	 * 
	 * item=DBHelper.executeSelect (con,SQLMapper.FETCHITEMID,SQLMapper.ITEMMAPPER,
	 * ITEMPMAPPER );
	 * 
	 * } catch (Exception e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); } return item;
	 * 
	 */

	public static int insertRegister(Users u) {
		// TODO Auto-generated method stub
		return 0;
	}
 public static List dispItem1(int ch2) throws DBConnectionException {
		List items = null;
		ConnectionHolder ch = null;
		Connection con = null;
		try {
			/*
			 * ch=ConnectionHolder.getInstance(); con=ch.getConnection();
			 */
			final ParamMapper ITEMPMAPPER = new ParamMapper() {

				public void mapParam(PreparedStatement preStmt) throws SQLException {
					preStmt.setInt(1, ch2);

				}

			};
			// log.debug("fetchig");
			items = DBHelper.executeSelect(con, SQLMapper.FETCHITEMID, SQLMapper.ITEMMAPPER, ITEMPMAPPER);

		} catch (Exception e) {
			throw new DBConnectionException("Unable to connect to db" + e);

		} finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}

		return items;

	}

	public static List dispItem2(int ch3) throws DBConnectionException {
		List items = null;
		ConnectionHolder ch = null;
		Connection con = null;
		try {
			/*
			 * ch=ConnectionHolder.getInstance(); con=ch.getConnection();
			 */
			final ParamMapper ITEMPMAPPER = new ParamMapper() {

				public void mapParam(PreparedStatement preStmt) throws SQLException {
					preStmt.setInt(1, ch3);

				}

			};
			// log.debug("fetchig");
			items = DBHelper.executeSelect(con, SQLMapper.FETCHITEMID, SQLMapper.ITEMMAPPER, ITEMPMAPPER);

		} catch (Exception e) {
			throw new DBConnectionException("Unable to connect to db" + e);

		} finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}

		return items;

	}

///////////////////////////////////////////////////////////////////////////////////////
	public static int insertOrder(final Orderlist o) {
		ConnectionHolder ch = null;
		Connection con = null;
		int result = 0;

		try {
			/*
			 * ch=ConnectionHolder.getInstance(); con=ch.getConnection();
			 */
			con = Dbconnnection.doConnection(con);
			final ParamMapper INSERTPORDER = new ParamMapper() {

				public void mapParam(PreparedStatement preStmt) throws SQLException {
					preStmt.setInt(1, o.getOid());
					preStmt.setInt(2, o.getUid());
					preStmt.setInt(3, o.getItemid());
					preStmt.setString(4, o.getRequested_date());
					preStmt.setInt(5, o.getQuantity());
					preStmt.setString(6, o.getAddress());

				}
			};

			result = DBHelper.executeUpdate(con, SQLMapper.INSERTORDER, INSERTPORDER);
			if (con != null) {
				con.close();
			}

		} catch (DBFWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;

	}//
///////////////////////////////////////////////////////////////////////////////////////////

	public static int insertOrder3(final Orderlist o)// for updation
	{
		ConnectionHolder ch = null;
		Connection con = null;
		int result = 0;

		try {
			con = Dbconnnection.doConnection(con);

			/*
			 * ch=ConnectionHolder.getInstance(); con=ch.getConnection();
			 */
			final ParamMapper INSERTPORDER = new ParamMapper() {

				public void mapParam(PreparedStatement preStmt) throws SQLException {

					preStmt.setInt(1, o.getQuantity());
					preStmt.setInt(2, o.getItemid());

				}
			};

			result = DBHelper.executeUpdate(con, SQLMapper.UPFDATEORDER3, INSERTPORDER);
			if (con != null) {
				con.close();
			}
		} catch (DBFWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;

	}///

	public static List getOrder(final int oid, final int uid, final int itemid, final String requested_date,
			final int quantity, final String address) {
		ConnectionHolder ch = null;
		Connection con = null;
		List register = null;

		try {/*
				 * ch=ConnectionHolder.getInstance(); con=ch.getConnection();
				 */
			final ParamMapper USERPMAPPER = new ParamMapper() {

				public void mapParam(PreparedStatement preStmt) throws SQLException {
					preStmt.setInt(1, oid);
					preStmt.setInt(2, uid);
					// preStmt.setString(3,uname);
					preStmt.setInt(3, itemid);
					preStmt.setString(4, requested_date);
					preStmt.setInt(5, quantity);
					preStmt.setString(6, address);

				}

			};// ananymous class

			register = DBHelper.executeSelect(con, SQLMapper.FETCHUSER, SQLMapper.USERMAPPER, USERPMAPPER);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return register;

	}

	public static int insertOrder1(Orderlist o) throws DBFWException {
		ConnectionHolder ch = null;
		Connection con = null;
		int register = 0;

		try {/*
				 * ch=ConnectionHolder.getInstance(); con=ch.getConnection();
				 */
			final ParamMapper INSERTPORDER = new ParamMapper() {

				public void mapParam(PreparedStatement preStmt) throws SQLException {
					preStmt.setInt(1, o.getOid());
					preStmt.setInt(2, o.getUid());

					preStmt.setInt(3, o.getItemid());
					preStmt.setString(4, o.getRequested_date());
					preStmt.setInt(5, o.getQuantity());
					preStmt.setString(6, o.getAddress());
					preStmt.setString(7, o.getDispatch_status());

				}

			};// ananymous class

			register = DBHelper.executeUpdate(con, SQLMapper.INSERTORDER1, INSERTPORDER);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return register;

	}

	public static List dispOrder2(int uid3) throws DBConnectionException {
		List orders = null;
		ConnectionHolder ch = null;
		Connection con = null;
		try {
			/*
			 * ch=ConnectionHolder.getInstance(); con=ch.getConnection();
			 */
			final ParamMapper ORDERPMAPPER = new ParamMapper() {

				public void mapParam(PreparedStatement preStmt) throws SQLException {
					preStmt.setInt(1, uid3);

				}

			};
			// log.debug("fetchig");
			orders = DBHelper.executeSelect(con, SQLMapper.FETCHORDER, SQLMapper.ORDERLISTMAPPER, ORDERPMAPPER);

		} catch (Exception e) {
			throw new DBConnectionException("Unable to connect to db" + e);

		} finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}

		return orders;

	}

	public static int updateOrder(final Orderlist o) {
		ConnectionHolder ch = null;
		Connection con = null;
		int result = 0;

		try {
			/*
			 * ch=ConnectionHolder.getInstance(); con=ch.getConnection();
			 */
			final ParamMapper ORDERPMAPPER = new ParamMapper() {

				public void mapParam(PreparedStatement preStmt) throws SQLException {
					preStmt.setInt(2, o.getUid());
					preStmt.setInt(1, o.getItemid());

				}

			};

			result = DBHelper.executeUpdate(con, SQLMapper.UPFDATEORDER, ORDERPMAPPER);

		} catch (DBFWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return result;

	}

	public static int deleteOrder(final Orderlist o) {
		ConnectionHolder ch = null;
		Connection con = null;
		int delete = 0;

		try {
			/*
			 * ch=ConnectionHolder.getInstance(); con=ch.getConnection();
			 */
			final ParamMapper ORDERPMAPPER = new ParamMapper() {

				public void mapParam(PreparedStatement preStmt) throws SQLException {
					preStmt.setInt(1, o.getOid());

				}

			};

			delete = DBHelper.executeUpdate(con, SQLMapper.DELETEORDER, ORDERPMAPPER);

		} catch (DBFWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return delete;

	}

	public static List getOrder1() throws DBConnectionException, DBFWException {
		List orders = null;
		ConnectionHolder ch = null;
		Connection con = null;
		try {
			/*
			 * ch=ConnectionHolder.getInstance(); con=ch.getConnection();
			 */
			orders = DBHelper.executeSelect(con, SQLMapper.FETCHORDER1, SQLMapper.ORDERLISTMAPPER1);

		} catch (Exception e) {
			throw new DBConnectionException("Unable to connect to db" + e);

		} finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}

		return orders;

	}

	public static int updateOrder1(final Orderlist o1) {
		ConnectionHolder ch = null;
		Connection con = null;
		int order1 = 0;

		try {
			/*
			 * ch=ConnectionHolder.getInstance(); con=ch.getConnection();
			 */
			con = Dbconnnection.doConnection(con);
			
			final ParamMapper ORDERPMAPPER1 = new ParamMapper() {

				public void mapParam(PreparedStatement preStmt) throws SQLException {
					preStmt.setInt(2, o1.getOid());
					preStmt.setString(1, o1.getDispatch_status());
					
				}

			};

			order1 = DBHelper.executeUpdate(con, SQLMapper.UPDATEORDER1, ORDERPMAPPER1);

		} catch (DBFWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return order1;

	}
	public  static List dispOrder() {
		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs=null;
		List<ViewOrderAll> l1 = new ArrayList();
		try
		{

		PreparedStatement ps = null;
		conn = Dbconnnection.doConnection(conn);
		
		String str = "select * from tbl_orderlist";
		ps = conn.prepareStatement(str);
		rs = ps.executeQuery();
		//System.out.println(rs);
		while(rs.next())
		{
		l1.add(new ViewOrderAll(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getString(4),rs.getInt(5),rs.getString(6),rs.getString(7)));
		System.out.println("printing");


		System.out.println(l1.toString());
		}
		}
		catch(Exception e)
		{
		System.out.println(e.toString());
		}
		finally
		{
		try
		{
		if(stmt!=null)
		stmt.close();
		if(conn!=null)
		conn.close();
		}
		catch(Exception et)
		{
		System.out.println(et.toString());
		}
		}
		return l1;
		}

		
	}

