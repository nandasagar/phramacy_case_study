package model;


public class LoginValidate 
{
	//adminlogin
  public static boolean adminLoginValidate(String id)
  {
	  for(int i=0;i<id.length();i++)
		{
			if(id.charAt(i)>=48 && id.charAt(i)<=56)  
			{
				System.out.println("valid");
	            
			}
		}
	  return true;
  }
  
  
  //userlogin
  public static boolean userLoginValidate(int id)
  {
	  
			if(id>=44 || id<=53)  
			{
				System.out.println("valid");
	            
			}
		
	  return true;
  }
  
 
}
