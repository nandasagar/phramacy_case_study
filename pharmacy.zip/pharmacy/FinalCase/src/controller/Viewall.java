package controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.RegistrationDAO;

/**
 * Servlet implementation class Viewall
 */
@WebServlet("/Viewall")
public class Viewall extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		

PrintWriter out = response.getWriter();
List l1 = new ArrayList();
String filepath1 =null;

RegistrationDAO drive = new RegistrationDAO();
l1= drive.dispOrder();
request.setAttribute("vieworder", l1);
filepath1="viewall.jsp";
RequestDispatcher rd = request.getRequestDispatcher(filepath1);
//RequestDispatcher rd = request.getRequestDispatcher(res);//for calling from the different class
rd.forward(request, response);

		
		
		
	}

}
