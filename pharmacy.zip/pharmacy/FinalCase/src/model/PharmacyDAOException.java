package model;

public class PharmacyDAOException {
	public PharmacyDAOException(String arg0, Throwable arg1) {
		super();
		// TODO Auto-generated constructor stub
	}

	public PharmacyDAOException(String arg0) {
		super();
		// TODO Auto-generated constructor stub
	}

}
