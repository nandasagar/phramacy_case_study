package model;

public class Product {

	private int pid,cid;
	private String productname;

	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getProductname() {
		return productname;
	}
	public void setProductname(String productname) {
		this.productname = productname;
	}
	public Product(int pid, int cid, String productname) {
		super();
		this.pid = pid;
		this.cid = cid;
		this.productname = productname;
	}

}
