package model;



public class RegisterValidation 
{
	public int adminRegister(String name,String email,String number)
	{
		int count=1;
			for(int i=0;i<name.length();i++)
			{

				if(!((name.charAt(i)>=65 && name.charAt(i)<=90) || (name.charAt(i)>=97 && name.charAt(i)<=122) ))
				{
					  count--;
			
				  
				}
			}
			
			
			for(int i=0;i<name.length();i++)
			{

				if(!(email.contains("@"))) 
				{
					  count--;
			
				  
				}
			}
			if(number.length()!=10)
			{
				count--;
			}
	
	return count;
	
	}
	
	
	
}
	


		    


