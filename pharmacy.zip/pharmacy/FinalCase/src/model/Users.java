package model;

public class Users {
private	int rid,uid,age,pincode;
String phonenum;// change 
private	String uname,city,state,emailid,password;
public Users(int rid, int uid, int age, String phonenum2, int pincode, String uname, String city, String state,
		String emailid, String password) {
	super();
	this.rid = rid;
	this.uid = uid;
	this.age = age;
	this.phonenum = phonenum2;
	this.pincode = pincode;
	this.uname = uname;
	this.city = city;
	this.state = state;
	this.emailid = emailid;
	this.password = password;
}
public Users(int uid, String password) {
	super();
	this.uid = uid;
	this.password = password;
}

public int getRid() {
	return rid;
}
public void setRid(int rid) {
	this.rid = rid;
}
public int getUid() {
	return uid;
}
public void setUid(int uid) {
	this.uid = uid;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getPhonenum() {
	return phonenum;
}
public void setPhonenum(String phonenum) {
	this.phonenum = phonenum;
}
public int getPincode() {
	return pincode;
}
public void setPincode(int pincode) {
	this.pincode = pincode;
}
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getEmailid() {
	return emailid;
}
public void setEmailid(String emailid) {
	this.emailid = emailid;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String toString() {
	return "Order [r_id=" + rid + ", user_id=" + uid + ", age=" + age + ",phonenum="
			+ phonenum + ", pincode=" + pincode + ", uname=" + uname + ", city="
			+ city + ",state=" + state + ",emailid="+ emailid +",password="+password+"]\n";
}

}
